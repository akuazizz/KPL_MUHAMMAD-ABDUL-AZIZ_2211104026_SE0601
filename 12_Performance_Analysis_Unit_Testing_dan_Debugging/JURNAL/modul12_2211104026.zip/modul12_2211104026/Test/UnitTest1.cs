﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using modul12_2211104026;

[TestClass]
public class UnitTestPangkat
{
    [TestMethod]
    public void TestPangkatNormal()
    {
        var form = new Form1();
        Assert.AreEqual(8, form.CariNilaiPangkat(2, 3));
    }

    [TestMethod]
    public void TestPangkatBIsZero()
    {
        var form = new Form1();
        Assert.AreEqual(1, form.CariNilaiPangkat(0, 0));
    }

    [TestMethod]
    public void TestPangkatBNegative()
    {
        var form = new Form1();
        Assert.AreEqual(-1, form.CariNilaiPangkat(2, -2));
    }

    [TestMethod]
    public void TestPangkatBGreaterThan10()
    {
        var form = new Form1();
        Assert.AreEqual(-2, form.CariNilaiPangkat(2, 11));
    }

    [TestMethod]
    public void TestPangkatAGreaterThan100()
    {
        var form = new Form1();
        Assert.AreEqual(-2, form.CariNilaiPangkat(101, 2));
    }

    [TestMethod]
    public void TestOverflow()
    {
        var form = new Form1();
        Assert.AreEqual(-3, form.CariNilaiPangkat(50000, 3)); // 50000^3 > max int
    }
}
