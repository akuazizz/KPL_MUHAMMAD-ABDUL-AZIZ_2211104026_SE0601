﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using tpmodul12_2211104026;

namespace tpmodul12_2211104026_Test
{
    [TestClass]
    public class TandaBilanganTests
    {
        [TestMethod]
        public void TestNegatif()
        {
            Form1 form = new Form1();
            string hasil = form.CariTandaBilangan(-10);
            Assert.AreEqual("Negatif", hasil);
        }

        [TestMethod]
        public void TestNol()
        {
            Form1 form = new Form1();
            string hasil = form.CariTandaBilangan(0);
            Assert.AreEqual("Nol", hasil);
        }

        [TestMethod]
        public void TestPositif()
        {
            Form1 form = new Form1();
            string hasil = form.CariTandaBilangan(10);
            Assert.AreEqual("Positif", hasil);
        }
    }
}