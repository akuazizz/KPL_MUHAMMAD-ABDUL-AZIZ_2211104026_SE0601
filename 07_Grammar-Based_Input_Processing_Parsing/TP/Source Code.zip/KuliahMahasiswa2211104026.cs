﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

public class Jadwal
{
    public string Code { get; set; }
    public string Name { get; set; }
}

public class KuliahMahasiswa2211104026
{
    public List<Jadwal> Courses { get; set; }

    public static void ReadJSON()
    {
        string path = @"E:\KPL\tpmodul7_2211104026\tpmodul7_2211104026\tp7_2_2211104026.json";
        if (File.Exists(path))
        {
            string jsonData = File.ReadAllText(path);
            var mahasiswa = JsonConvert.DeserializeObject<KuliahMahasiswa2211104026>(jsonData);

            Console.WriteLine("Daftar mata kuliah yang diambil:");
            int index = 1;
            foreach (var course in mahasiswa.Courses)
            {
                Console.WriteLine($"MK {index} {course.Code} - {course.Name}");
                index++;
            }
        }
        else
        {
            Console.WriteLine("File JSON tidak ditemukan!");
        }
    }
}
