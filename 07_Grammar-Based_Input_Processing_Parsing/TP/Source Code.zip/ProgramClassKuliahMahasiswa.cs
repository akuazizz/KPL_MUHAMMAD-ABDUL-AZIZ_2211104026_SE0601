﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tpmodul7_2211104026
{
    class Program
    {
        static void Main(string[] args)
        {
            KuliahMahasiswa2211104026.ReadJSON();
        }
    }
}

