﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modul7_kelompok_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("=== Membaca Data Mahasiswa dari JSON ===");
            //DataMahasiswa2211104026.ReadJSON();

            //Console.WriteLine("=== Membaca Data Anggota Tim dari JSON ===");
            //TeamMembers2211104026.DisplayTeamData(@"E:\KPL\modul7_kelompok_3\modul7_kelompok_3\jurnal7_2_2211104026.json");

            //Console.WriteLine("=== Membaca Data Glossary dari JSON ===");
            //GlossaryItem.ReadJSON(@"E:\\KPL\\modul7_kelompok_3\\modul7_kelompok_3\jurnal7_3_2211104026.json");
        }
    }
}
