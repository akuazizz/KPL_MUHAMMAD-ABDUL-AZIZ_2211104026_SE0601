﻿using System;
using AljabarLibraries;

namespace tpmodul10_2211104026
{
    class Program
    {
        static void Main(string[] args)
        {
            // Contoh pemanggilan fungsi AkarPersamaanKuadrat
            double[] hasilAkar = Aljabar.AkarPersamaanKuadrat(new double[] { 1, -3, -10 });
            Console.WriteLine("Akar Persamaan Kuadrat:");
            Console.WriteLine($"x1 = {hasilAkar[0]}, x2 = {hasilAkar[1]}");

            // Contoh pemanggilan fungsi HasilKuadrat
            double[] hasilKuadrat = Aljabar.HasilKuadrat(new double[] { 2, -3 });
            Console.WriteLine("\nHasil Kuadrat dari (2x - 3)^2:");
            Console.WriteLine($"{hasilKuadrat[0]}x^2 {hasilKuadrat[1]}x {hasilKuadrat[2]}");
        }
    }
}
