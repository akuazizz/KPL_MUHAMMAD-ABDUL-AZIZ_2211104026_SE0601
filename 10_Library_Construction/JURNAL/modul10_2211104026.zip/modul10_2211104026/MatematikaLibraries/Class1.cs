﻿using System;

namespace MatematikaLibraries
{
    public class Matematika
    {
        public static int FPB(int input1, int input2)
        {
            while (input2 != 0)
            {
                int temp = input2;
                input2 = input1 % input2;
                input1 = temp;
            }
            return input1;
        }

        public static int KPK(int input1, int input2)
        {
            return (input1 * input2) / FPB(input1, input2);
        }

        public static string Turunan(int[] persamaan)
        {
            string hasil = "";
            int derajat = persamaan.Length - 1;
            for (int i = 0; i < persamaan.Length - 1; i++)
            {
                int koefisien = persamaan[i] * (derajat - i);
                int pangkat = derajat - i - 1;

                if (koefisien >= 0 && hasil.Length > 0)
                    hasil += " + ";
                else if (koefisien < 0)
                    hasil += " ";

                hasil += koefisien.ToString();
                if (pangkat > 1)
                    hasil += "x" + pangkat;
                else if (pangkat == 1)
                    hasil += "x";
            }
            return hasil;
        }

        public static string Integral(int[] persamaan)
        {
            string hasil = "";
            int derajat = persamaan.Length - 1;
            for (int i = 0; i < persamaan.Length; i++)
            {
                double koefisien = (double)persamaan[i] / (derajat - i + 1);
                int pangkat = derajat - i + 1;

                if (koefisien >= 0 && hasil.Length > 0)
                    hasil += " + ";
                else if (koefisien < 0)
                    hasil += " ";

                if (koefisien == 1)
                    hasil += "x" + pangkat;
                else if (koefisien == -1)
                    hasil += "-x" + pangkat;
                else
                    hasil += koefisien.ToString("0.#") + "x" + pangkat;
            }
            hasil += " + C";
            return hasil;
        }
    }
}
