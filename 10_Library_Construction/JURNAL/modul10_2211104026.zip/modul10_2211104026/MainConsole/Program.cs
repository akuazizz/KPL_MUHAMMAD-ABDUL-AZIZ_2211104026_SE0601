﻿using System;
using MatematikaLibraries;

namespace MainConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            // Testing FPB
            Console.WriteLine("FPB(60, 45) = " + Matematika.FPB(60, 45));

            // Testing KPK
            Console.WriteLine("KPK(12, 8) = " + Matematika.KPK(12, 8));

            // Testing Turunan
            int[] persamaanTurunan = { 1, 4, -12, 9 };
            Console.WriteLine("Turunan dari x3 + 4x2 -12x +9 adalah: " + Matematika.Turunan(persamaanTurunan));

            // Testing Integral
            int[] persamaanIntegral = { 4, 6, -12, 9 };
            Console.WriteLine("Integral dari 4x3 + 6x2 -12x +9 adalah: " + Matematika.Integral(persamaanIntegral));

            Console.ReadLine();
        }
    }
}