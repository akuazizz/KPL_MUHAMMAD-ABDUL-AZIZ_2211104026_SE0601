﻿using System;
using AljabarLibraries;

namespace tpmodul14_2211104026
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Aljabar aljabar = new Aljabar();

            // Input koefisien persamaan kuadrat ax^2 + bx + c
            double[] koefKuadrat = { 1, -3, 2 };
            double[] akar = aljabar.HitungAkarPersamaanKuadrat(koefKuadrat);

            Console.WriteLine("Akar-akar persamaan kuadrat:");
            foreach (double hasil in akar)
            {
                Console.WriteLine(hasil);
            }

            // Input koefisien dari bentuk (ax + b)^2
            double[] koefLinier = { 2, 3 };
            double[] hasilKuadrat = aljabar.HitungHasilKuadrat(koefLinier);

            Console.WriteLine("\nHasil dari (ax + b)^2:");
            Console.WriteLine($"{hasilKuadrat[0]}x^2 + {hasilKuadrat[1]}x + {hasilKuadrat[2]}");
        }
    }
}
