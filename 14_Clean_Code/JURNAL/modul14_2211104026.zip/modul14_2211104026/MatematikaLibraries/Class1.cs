﻿using System;

namespace MatematikaLibraries
{
    public class Matematika
    {
        public static int Fpb(int angka1, int angka2)
        {
            while (angka2 != 0)
            {
                int sisa = angka1 % angka2;
                angka1 = angka2;
                angka2 = sisa;
            }
            return angka1;
        }

        public static int Kpk(int angka1, int angka2)
        {
            return (angka1 * angka2) / Fpb(angka1, angka2);
        }

        public static string HitungTurunan(int[] koefisien)
        {
            string hasil = "";
            int derajat = koefisien.Length - 1;

            for (int i = 0; i < koefisien.Length - 1; i++)
            {
                int nilai = koefisien[i] * (derajat - i);
                int pangkat = derajat - i - 1;

                if (nilai > 0 && hasil.Length > 0)
                    hasil += " + ";
                else if (nilai < 0)
                    hasil += " ";

                hasil += nilai.ToString();
                if (pangkat > 1)
                    hasil += "x^" + pangkat;
                else if (pangkat == 1)
                    hasil += "x";
            }

            return hasil;
        }

        public static string HitungIntegral(int[] koefisien)
        {
            string hasil = "";
            int derajat = koefisien.Length - 1;

            for (int i = 0; i < koefisien.Length; i++)
            {
                double nilai = (double)koefisien[i] / (derajat - i + 1);
                int pangkat = derajat - i + 1;

                if (nilai > 0 && hasil.Length > 0)
                    hasil += " + ";
                else if (nilai < 0)
                    hasil += " ";

                if (nilai == 1)
                    hasil += "x^" + pangkat;
                else if (nilai == -1)
                    hasil += "-x^" + pangkat;
                else
                    hasil += nilai.ToString("0.#") + "x^" + pangkat;
            }

            hasil += " + C";
            return hasil;
        }
    }
}