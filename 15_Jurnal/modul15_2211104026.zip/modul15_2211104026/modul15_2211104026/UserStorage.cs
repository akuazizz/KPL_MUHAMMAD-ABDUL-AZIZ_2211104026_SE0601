﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

public static class UserStorage
{
    private static string path = "users.json";

    public static List<User> LoadUsers()
    {
        if (!File.Exists(path)) return new List<User>();
        string json = File.ReadAllText(path);
        return JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();
    }

    public static void SaveUsers(List<User> users)
    {
        string json = JsonConvert.SerializeObject(users, Formatting.Indented);
        File.WriteAllText(path, json);
    }
}