﻿using System.Linq;
using System.Security.Cryptography;
using System.Text;

public static class Helper
{
    public static string ComputeSha256Hash(string rawData)
    {
        using (SHA256 sha256 = SHA256.Create())
        {
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(rawData));
            StringBuilder builder = new StringBuilder();
            foreach (var b in bytes)
                builder.Append(b.ToString("x2"));
            return builder.ToString();
        }
    }

    public static bool IsValidInput(string username, string password, out string error)
    {
        error = "";

        // Validasi panjang
        if (username.Length < 8 || username.Length > 20)
        {
            error = "Username harus 8-20 karakter.";
            return false;
        }

        if (password.Length < 8 || password.Length > 20)
        {
            error = "Password harus 8-20 karakter.";
            return false;
        }

        // Validasi karakter ASCII
        if (!username.All(c => c >= 32 && c <= 126))
        {
            error = "Username hanya boleh karakter ASCII.";
            return false;
        }

        // Password mengandung angka
        if (!password.Any(char.IsDigit))
        {
            error = "Password harus mengandung angka.";
            return false;
        }

        // Password harus punya karakter unik
        if (!password.Any(ch => "!@#$%^&*".Contains(ch)))
        {
            error = "Password harus mengandung minimal 1 karakter unik (!@#$%^&*).";
            return false;
        }

        // Password tidak boleh mengandung username
        if (password.ToLower().Contains(username.ToLower()))
        {
            error = "Password tidak boleh mengandung username.";
            return false;
        }

        return true;
    }
}