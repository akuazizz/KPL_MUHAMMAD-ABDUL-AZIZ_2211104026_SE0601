﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modul15_2211104026
{
    public partial class RegisterForm: Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnSubmitReg_Click(object sender, EventArgs e)
        {
            string username = txtUsernameReg.Text.Trim();
            string password = txtPasswordReg.Text;

            if (!Helper.IsValidInput(username, password, out string error))
            {
                MessageBox.Show(error);
                return;
            }

            var users = UserStorage.LoadUsers();

            if (users.Any(u => u.Username == username))
            {
                MessageBox.Show("Username sudah terdaftar.");
                return;
            }

            string hashed = Helper.ComputeSha256Hash(password);
            users.Add(new User { Username = username, PasswordHash = hashed });
            UserStorage.SaveUsers(users);

            MessageBox.Show("Registrasi berhasil!");
            this.Close();
        }
    }
}
