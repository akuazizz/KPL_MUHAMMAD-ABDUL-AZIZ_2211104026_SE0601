﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modul15_2211104026
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string hashed = Helper.ComputeSha256Hash(password);

            var users = UserStorage.LoadUsers();

            var user = users.FirstOrDefault(u => u.Username == username && u.PasswordHash == hashed);

            if (user != null)
                MessageBox.Show("Login sukses!");
            else
                MessageBox.Show("Username atau password salah.");
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            new RegisterForm().ShowDialog();
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
