﻿using System;
using System.Collections.Generic;
class SayaTubeVideo
{
    private int id;
    private string title;
    private int playCount;

    public SayaTubeVideo(string title)
    {
        if (string.IsNullOrEmpty(title))
            throw new ArgumentException("Title cannot be null or empty");
        if (title.Length > 200)
            throw new ArgumentException("Title cannot exceed 200 characters");

        Random random = new Random();
        this.id = random.Next(10000, 99999);
        this.title = title;
        this.playCount = 0;
    }

    public void IncreasePlayCount(int count)
    {
        if (count < 0 || count > 25000000)
            throw new ArgumentException("Play count increment must be between 0 and 25,000,000");

        checked
        {
            try
            {
                playCount += count;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Error: Play count overflow detected");
            }
        }
    }

    public void PrintVideoDetails()
    {
        Console.WriteLine($"ID: {id}");
        Console.WriteLine($"Title: {title}");
        Console.WriteLine($"Play Count: {playCount}");
    }

    public int GetPlayCount()
    {
        return playCount;
    }

    public string GetTitle()
    {
        return title;
    }
}

class SayaTubeUser
{
    private int id;
    private string Username;
    private List<SayaTubeVideo> uploadedVideos;

    public SayaTubeUser(string username)
    {
        if (string.IsNullOrEmpty(username))
            throw new ArgumentException("Username cannot be null or empty");
        if (username.Length > 100)
            throw new ArgumentException("Username cannot exceed 100 characters");

        Random random = new Random();
        this.id = random.Next(10000, 99999);
        this.Username = username;
        this.uploadedVideos = new List<SayaTubeVideo>();
    }

    public void AddVideo(SayaTubeVideo video)
    {
        if (video == null)
            throw new ArgumentNullException("Video cannot be null");
        if (video.GetPlayCount() >= int.MaxValue)
            throw new ArgumentException("Video play count is too large");

        uploadedVideos.Add(video);
    }

    public int GetTotalVideoPlayCount()
    {
        int total = 0;
        foreach (var video in uploadedVideos)
        {
            total += video.GetPlayCount();
        }
        return total;
    }

    public void PrintAllVideoPlaycount()
    {
        Console.WriteLine($"User: {Username}");
        for (int i = 0; i < Math.Min(8, uploadedVideos.Count); i++)
        {
            Console.WriteLine($"Video {i + 1} judul: {uploadedVideos[i].GetTitle()}");
        }
    }
}

class Program
{
    static void Main()
    {
        try
        {
            SayaTubeUser user = new SayaTubeUser("Abdul Aziz");

            List<string> movieTitles = new List<string>
            {
                "Review Film Dilan oleh Abdul Aziz",
                "Review Film Pengabdi Setan oleh Abdul Aziz",
                "Review Film Susah Sinyal oleh Abdul Aziz",
                "Review Film Milea oleh Abdul Aziz",
                "Review Film Makmum oleh Abdul Aziz",
                "Review Film Avengers: Endgame oleh Abdul Aziz",
                "Review Film Sewu Dino oleh Abdul Aziz",
                "Review Film Ipar Adalah Maut oleh Abdul Aziz",
                "Review Film Joker oleh Abdul Aziz",
                "Review Film Spider-Man: No Way Home oleh Abdul Aziz"
            };

            foreach (var title in movieTitles)
            {
                SayaTubeVideo video = new SayaTubeVideo(title);
                video.IncreasePlayCount(new Random().Next(1000, 5000));
                user.AddVideo(video);
            }

            user.PrintAllVideoPlaycount();
            Console.WriteLine($"Total Play Count: {user.GetTotalVideoPlayCount()}");

            // Test overflow condition
            SayaTubeVideo testVideo = new SayaTubeVideo("Test Overflow Video");
            for (int i = 0; i < 10; i++)
            {
                testVideo.IncreasePlayCount(int.MaxValue / 5);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception: {ex.Message}");
        }
    }
}